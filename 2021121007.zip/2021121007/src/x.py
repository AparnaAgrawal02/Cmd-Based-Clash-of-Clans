
from colorama import Fore, Back, Style
print(len(Fore.LIGHTWHITE_EX))
